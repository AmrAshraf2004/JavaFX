module advancedprogramming.cardealershipnetbeans {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    
    requires javafx.base;
    requires javafx.graphics;
    
    requires org.kordamp.ikonli.core;
    requires org.kordamp.ikonli.javafx;
    // add icon pack modules
    requires org.kordamp.ikonli.fontawesome;
    requires java.base;
    
    requires javafx.media; // This is the correct module requirement
    
    opens advancedprogramming.cardealershipnetbeans to javafx.fxml;
    exports advancedprogramming.cardealershipnetbeans;
}
