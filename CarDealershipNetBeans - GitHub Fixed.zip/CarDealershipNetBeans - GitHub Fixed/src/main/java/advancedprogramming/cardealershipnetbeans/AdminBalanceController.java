package advancedprogramming.cardealershipnetbeans;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import java.util.Date;

public class AdminBalanceController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        AdminLoginController adminLoginController = AdminLoginController.getInstance();
        this.admin = adminLoginController.admin;
        
        // Initialize the thread with the user and controller
        AdminThread updateThread = new AdminThread(this);

        // Start the thread
        updateThread.start();
    }
    Admin admin;
    
    
    
    // Method to update admin information in the UI
    protected void updateInfo() {
        total_balance_label.setText("$"+String.valueOf(admin.getBalance()));
        money_spent_label.setText("$"+String.valueOf(admin.getMoneySpent()));

        last_deposit_date_label.setText(String.valueOf(admin.getLastDepositDate()));
        last_deposit_value_label.setText("$"+String.valueOf(admin.getLastDepositValue()));

        last_withdraw_date_label.setText(String.valueOf(admin.getLastWithdrawDate()));
        last_withdraw_value_label.setText("$"+String.valueOf(admin.getLastWithdrawValue()));
    }
   
    

    @FXML
    private Button sql_btn;

    @FXML
    private Button availableCars_btn;

    @FXML
    private Button cars_sold_btn;

    @FXML
    private Button deposit_withdraw_btn;

    @FXML
    private Button go_add_cars_btn;

    @FXML
    private Button home_btn;

    @FXML
    private AnchorPane home_form;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private TextField balanceTextField;

    @FXML
    private TextField cardNumberTextField;

    @FXML
    private TextField cvvTextField;

    @FXML
    private Button deposit_balance_btn;

    @FXML
    private TextField expiryDateTextField;

    @FXML
    private Label last_deposit_date_label;

    @FXML
    private Label last_deposit_value_label;

    @FXML
    private Label last_withdraw_date_label;

    @FXML
    private Label last_withdraw_value_label;

    @FXML
    private Label money_spent_label;

    @FXML
    private Label status_label_failure;

    @FXML
    private Label status_label_success;

    @FXML
    private Label tansaction_label;

    @FXML
    private Label total_balance_label;

    @FXML
    private Button withdraw_balance_btn;

    @FXML
    private void depositBalance(ActionEvent event) {
        String cardNumber = cardNumberTextField.getText();
        String expirationDate = expiryDateTextField.getText();
        String cvv = cvvTextField.getText();
        double balance = Double.parseDouble(balanceTextField.getText());

        if (Utils.validateCardInfo(cardNumber, expirationDate, cvv)) {
            // Perform actions if card information is valid
            // Set last transaction date and value, update admin's balance, etc.
            admin.setLastDepositDate(new Date());
            admin.setLastDepositValue(balance);
            admin.deposit(balance);
            
            
        } else {
            // Display error message if card information is invalid
            App.showAlert("Failure", "Invalid parameters", "Please try again");
            tansaction_label.setText("Transaction Failed");
            status_label_failure.setText("Failure");
        }
    }

    @FXML
    private void withdrawBalance(ActionEvent event) {
        String cardNumber = cardNumberTextField.getText();
        String expirationDate = expiryDateTextField.getText();
        String cvv = cvvTextField.getText();
        double balance = Double.parseDouble(balanceTextField.getText());

        if (Utils.validateCardInfo(cardNumber, expirationDate, cvv)) {
            // Perform actions if card information is valid
            // Set last transaction date and value, update admin's balance, etc.
            admin.setLastWithdrawDate(new Date());
            admin.setLastWithdrawValue(balance);
            admin.withdraw(balance);
            
            
        } else {
            // Display error message if card information is invalid
            App.showAlert("Failure", "Invalid parameters", "Please try again");
            tansaction_label.setText("Transaction Failed");
            status_label_failure.setText("Failure");
        }
    }

    @FXML
    private void switchToAddCars(ActionEvent event) throws IOException {
        App.setRoot("admin-add-cars");
    }

    @FXML
    private void switchToAvailableCars(ActionEvent event) throws IOException {
        App.setRoot("admin-available-cars");
    }

    @FXML
    private void switchToCarsSold(ActionEvent event) throws IOException {
        App.setRoot("admin-cars-sold");
    }

    @FXML
    private void switchToDepositWithdraw(ActionEvent event) throws IOException {
        App.setRoot("admin-deposit-withdraw");
    }

    @FXML
    private void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("admin-view");
    }

    @FXML
    private void switchToSQLView(ActionEvent event) throws IOException {
        App.setRoot("admin-sql");
    }
    
    @FXML
    private void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900,600);
        App.setRoot("Welcome");
    }
}
