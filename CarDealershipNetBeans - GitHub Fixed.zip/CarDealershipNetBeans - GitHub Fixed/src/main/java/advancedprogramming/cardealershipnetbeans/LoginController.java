package advancedprogramming.cardealershipnetbeans;


import java.io.IOException;
import java.net.URL;
import static java.sql.JDBCType.NULL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    User user;
    
    @FXML
    private Button adminButton;

    
    @FXML
    private Button btn_go_login;

    @FXML
    private PasswordField password_txt_field;

    @FXML
    private Hyperlink return_to_signup_link;

    @FXML
    private TextField username_txt_field;

    
@FXML
protected void switchToLogin(ActionEvent event) throws IOException {
    String username = username_txt_field.getText();
    String password = password_txt_field.getText();

    // Retrieve user from database by username
    User user = DatabaseHelper.getUserByUsername(username);

    if (user != null && user.getPassword().equals(password)) {
        // Set the currentUser object
        this.user = user;
        this.instance= new LoginController();
        this.instance.user = user;
        
        App.changeSceneSize(1130,650);
        App.setRoot("user-view");
        
    } else {
        // Show error message if user not found or password is incorrect
        App.showAlert("Login Error", "Invalid credentials", "Please check your username and password.");
    }
}
    
    // This is to have a template to all classes to get the current user that is running program
    private static LoginController instance;

    public static LoginController getInstance() { //Called by all User Controllers to get the user
        return instance;
    }

    @FXML
    protected void switch_to_signup(ActionEvent event) throws IOException {
        App.setRoot("signup");
    }
    
    @FXML
    void switchToAdminView(ActionEvent event) throws IOException {
        App.setRoot("admin-login");
        
    }
    
}
