
package advancedprogramming.cardealershipnetbeans;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils { 

    
    //Validate Sign up data
    protected static boolean isValidSignup(String username, String password, String email, String firstName, String lastName) {
        boolean isValid = true;

        if (username == null || username.isEmpty()) {
            App.showAlert("Error", null, "Username cannot be empty.");
            isValid = false;
        }

        if (password == null || password.isEmpty()) {
            App.showAlert("Error", null, "Password cannot be empty.");
            isValid = false;
        } else if (password.length() < 8) {
            App.showAlert("Error", null, "Password must be at least 8 characters long.");
            isValid = false;
        }

        if (email == null || email.isEmpty()) {
            App.showAlert("Error", null, "Email cannot be empty.");
            isValid = false;
        } else if (!Pattern.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", email)) {
            App.showAlert("Error", null, "Invalid email format.");
            isValid = false;
        }

        if (firstName == null || firstName.length() < 3) {
            App.showAlert("Error", null, "First name must be at least 3 characters long.");
            isValid = false;
        }

        if (lastName == null || lastName.length() < 3) {
            App.showAlert("Error", null, "Last name must be at least 3 characters long.");
            isValid = false;
        }

        return isValid;
    
}
    
    
    
    public static boolean validateCardInfo(String cardNumber, String expirationDate, String cvv) {
        // Define regex patterns for card number, expiration date, and CVV
        String cardNumberRegex = "^\\d{16}$";
        String expirationDateRegex = "^(0[1-9]|1[0-2])/[0-9]{2}$";
        String cvvRegex = "^\\d{3}$";

        // Compile regex patterns
        Pattern cardNumberPattern = Pattern.compile(cardNumberRegex);
        Pattern expirationDatePattern = Pattern.compile(expirationDateRegex);
        Pattern cvvPattern = Pattern.compile(cvvRegex);

        // Match card information against regex patterns
        Matcher cardNumberMatcher = cardNumberPattern.matcher(cardNumber);
        Matcher expirationDateMatcher = expirationDatePattern.matcher(expirationDate);
        Matcher cvvMatcher = cvvPattern.matcher(cvv);

        // Check if all card information matches the regex patterns
        return cardNumberMatcher.matches() && expirationDateMatcher.matches() && cvvMatcher.matches();
    }

    
}
