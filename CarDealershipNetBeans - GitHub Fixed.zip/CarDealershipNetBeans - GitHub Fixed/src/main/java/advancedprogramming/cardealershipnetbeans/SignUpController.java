package advancedprogramming.cardealershipnetbeans;

import javafx.scene.control.Alert;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class SignUpController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    
    @FXML
    private TextField FirstName_signup;

    @FXML
    private Button btn_go_signup;

    @FXML
    private TextField email_signup;

    @FXML
    private TextField lastName_signup;

    @FXML
    private PasswordField password_signup;

    @FXML
    private Hyperlink return_to_login_link;

    @FXML
    private TextField username_signup;

    @FXML
    protected void signup(ActionEvent event) throws IOException {
           String username = username_signup.getText();
           String email = email_signup.getText();
           String password = password_signup.getText();
           String firstName = FirstName_signup.getText();
           String lastName = lastName_signup.getText();

           // Perform input validation
           if(!(Utils.isValidSignup(username,password,email,firstName,lastName))) {
               App.setRoot("signup");
           }
            // Check if username or email already exists in the database
            else if (DatabaseHelper.isUsernameExists(username)) {
               App.showAlert("Username Error", "Username already exists", "Please choose a different username.");
               App.setRoot("signup");
           } else if (DatabaseHelper.isEmailExists(email)) {
               App.showAlert("Email Error", "Email already exists", "Please use a different email address.");
               App.setRoot("signup");
           } else {
               // Insert new user into the database
               App.showSuccessAlert("Success", "Account Created", "Please login now");
               DatabaseHelper.insertUser(username, password, email, firstName, lastName);
               User.setTotalCustomers();
               
               
               App.setRoot("login");
            }
           
            
    }

    @FXML
    protected void switch_to_login(ActionEvent event) throws IOException {
        App.setRoot("login");
    }
    
}





