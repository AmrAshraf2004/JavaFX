package advancedprogramming.cardealershipnetbeans;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AdminAddCarsController implements Initializable {

    private Admin admin;

    @FXML
    private Button availableCars_btn;
    @FXML
    private Button cars_sold_btn;
    @FXML
    private Button deposit_withdraw_btn;
    @FXML
    private Button go_add_cars_btn;
    @FXML
    private Button home_btn;
    @FXML
    private AnchorPane home_form;
    @FXML
    private Button logoutBtn;
    @FXML
    private AnchorPane main_form;
    @FXML
    private Button sql_btn;

    @FXML
    private Button add_car_btn;
    @FXML
    private ColorPicker carColorPicker;
    @FXML
    private TextField carId_textField;
    @FXML
    private ImageView carImageView;
    @FXML
    private AnchorPane carManipulationAnchorPane;
    @FXML
    private ChoiceBox<String> carTypeChoiceBox;
    @FXML
    private PieChart carTypesPieChart;
    @FXML
    private TextField car_horsepower_textField;
    @FXML
    private TextField car_make_textField;
    @FXML
    private TextField car_model_textField;
    @FXML
    private TextField car_top_speed_textField;
    @FXML
    private TextField car_year_textField;
    @FXML
    private Button clear_fields_btn;
    @FXML
    private ChoiceBox<String> fuelTypeChoiceBox;
    @FXML
    private Button import_photo_btn;
    @FXML
    private AnchorPane pieChartAnchorPane;
    @FXML
    private TextField price_to_pay_to_add_textField;
    @FXML
    private Button remove_car_btn;
    @FXML
    private TextField sale_price_textField;
    @FXML
    private ChoiceBox<String> transmissionChoiceBox;
    @FXML
    private Button update_car_btn;

    private String photoURL;
    private Color carColor;

    @FXML
    private AnchorPane carPricePerTopSpeedAnchor;

    @FXML
    private BarChart<String, Number> carPricePerTopSpeedChart;

    @FXML
    private AnchorPane carAverageTopSpeedPerFuelTypeAnchor;

    @FXML
    private BarChart<String, Number> carAverageTopSpeedPerFuelTypeChart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        AdminLoginController adminLoginController = AdminLoginController.getInstance();
        this.admin = adminLoginController.admin;

        // Initialize the thread with the user and controller
        AdminThread updateThread = new AdminThread(this);

        // Start the thread
        updateThread.start();

        // Initialize ChoiceBoxes with example values
        carTypeChoiceBox.getItems().addAll("Sedan", "SUV", "Muscle", "Sport", "Supercar", "Luxury", "Hatchback");
        fuelTypeChoiceBox.getItems().addAll("Gasoline", "Diesel", "Electric", "Hybrid");
        transmissionChoiceBox.getItems().addAll("Manual", "Automatic", "CVT", "Electric");

        // Load the car types pie chart
        loadCarTypesPieChart();
        // Load car price per top speed data
        loadCarPricePerTopSpeedChart();
        // Load average top speed per fuel type data
        loadAverageTopSpeedPerFuelTypeChart();
    }

    // Method to update information in the UI
    protected void updateInfo() {
        // This method can be used to periodically update information in the UI
    }

    @FXML
    private void handleSelectPhoto(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Photo");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp", "*.tiff", "*.webp", "*.avif"));

        // Show open file dialog
        File file = fileChooser.showOpenDialog(new Stage());
        if (file != null) {
            photoURL = file.toURI().toString();
            Image image = new Image(photoURL);
            carImageView.setImage(image);
        }
    }

    @FXML
private void addCar(ActionEvent event) {
    try {
        String make = car_make_textField.getText();
        String model = car_model_textField.getText();
        int horsepower = Integer.parseInt(car_horsepower_textField.getText());
        String fuelType = fuelTypeChoiceBox.getValue();
        String transmission = transmissionChoiceBox.getValue();
        int topSpeed = Integer.parseInt(car_top_speed_textField.getText());
        double costToAdd = Double.parseDouble(price_to_pay_to_add_textField.getText());
        double salePrice = Double.parseDouble(sale_price_textField.getText());
        int year = Integer.parseInt(car_year_textField.getText());
        String color = carColorPicker.getValue().toString();
        String carType = carTypeChoiceBox.getValue();
        Date dateAdded = new Date(System.currentTimeMillis());

        if (admin.getBalance() >= costToAdd) {
            Car.insertNewCar(make, model, horsepower, fuelType, transmission, topSpeed, salePrice, year, color, carType, photoURL, dateAdded);

            // Update admin's balance and money spent
            admin.buyCar(costToAdd);

            clearFields(event);
            loadCarTypesPieChart(); // Update pie chart after adding a car

            // Update car price per top speed data
            loadCarPricePerTopSpeedChart();

            // Update average top speed per fuel type data
            loadAverageTopSpeedPerFuelTypeChart();

            // Show success alert
            App.showSuccessAlert("Success", "Car Added", "The car has been added successfully.");
        } else {
            App.showAlert("Error", "Not Enough Money", "There is not enough money to buy the car.");
        }
    } catch (NumberFormatException e) {
        System.err.println("Invalid input: " + e.getMessage());
    }
}

    @FXML
    private void updateCar(ActionEvent event) {
        try {
            int carId = Integer.parseInt(carId_textField.getText());

            if (!car_make_textField.getText().isEmpty()) {
                Car.updateCar(carId, "make", car_make_textField.getText());
            }
            if (!car_model_textField.getText().isEmpty()) {
                Car.updateCar(carId, "model", car_model_textField.getText());
            }
            if (!car_horsepower_textField.getText().isEmpty()) {
                Car.updateCar(carId, "horsepower", Integer.parseInt(car_horsepower_textField.getText()));
            }
            if (fuelTypeChoiceBox.getValue() != null) {
                Car.updateCar(carId, "fuel_type", fuelTypeChoiceBox.getValue());
            }
            if (transmissionChoiceBox.getValue() != null) {
                Car.updateCar(carId, "transmission", transmissionChoiceBox.getValue());
            }
            if (!car_top_speed_textField.getText().isEmpty()) {
                Car.updateCar(carId, "top_speed", Integer.parseInt(car_top_speed_textField.getText()));
            }
            if (!price_to_pay_to_add_textField.getText().isEmpty()) {
                Car.updateCar(carId, "price", Double.parseDouble(price_to_pay_to_add_textField.getText()));
            }
            if (!car_year_textField.getText().isEmpty()) {
                Car.updateCar(carId, "year", Integer.parseInt(car_year_textField.getText()));
            }
            if (carColorPicker.getValue() != null) {
                Car.updateCar(carId, "color", carColorPicker.getValue().toString());
            }
            if (carTypeChoiceBox.getValue() != null) {
                Car.updateCar(carId, "car_type", carTypeChoiceBox.getValue());
            }
            if (photoURL != null && !photoURL.isEmpty()) {
                Car.updateCar(carId, "photo_url", photoURL);
            }

            clearFields(event);
            // Update Charts
            loadCarTypesPieChart();
            loadCarPricePerTopSpeedChart();
            loadAverageTopSpeedPerFuelTypeChart();
            App.showSuccessAlert("Success", "Car Updated", "The car has been updated successfully.");
        } catch (NumberFormatException e) {
            App.showAlert("Invalid Input", "Please enter valid values for car details.", e.getMessage());
            System.err.println("Invalid input: " + e.getMessage());
        } catch (Exception e) {
            App.showAlert("Update Failed", "An error occurred while updating the car.", e.getMessage());
            System.err.println("Error updating car: " + e.getMessage());
        }
    }

    @FXML
    private void removeCar(ActionEvent event) {
        try {
            int carId = Integer.parseInt(carId_textField.getText());
            Car.deleteCar(carId);
            clearFields(event);
            // Update Charts
            loadCarPricePerTopSpeedChart();
            loadCarTypesPieChart();
            loadAverageTopSpeedPerFuelTypeChart();
            App.showSuccessAlert("Success", "Car Removed", "The car has been removed successfully.");
        } catch (NumberFormatException e) {
            System.err.println("Invalid input: " + e.getMessage());
        }
    }

    @FXML
    private void clearFields(ActionEvent event) {
        carId_textField.clear();
        car_make_textField.clear();
        car_model_textField.clear();
        car_horsepower_textField.clear();
        fuelTypeChoiceBox.setValue(null);
        transmissionChoiceBox.setValue(null);
        car_top_speed_textField.clear();
        price_to_pay_to_add_textField.clear();
        car_year_textField.clear();
        carColorPicker.setValue(Color.WHITE);
        carTypeChoiceBox.setValue(null);
        carImageView.setImage(null);
        photoURL = null;
        sale_price_textField.clear();
    }

    private void loadCarTypesPieChart() {
        List<PieChart.Data> carTypeData = DatabaseHelper.getCarTypeStatistics();
        carTypesPieChart.getData().clear();
        carTypesPieChart.getData().addAll(carTypeData);
    }

    @FXML
    private void choseCarColor(ActionEvent event) {
        carColor = carColorPicker.getValue();
    }

    @FXML
    private void switchToAddCars(ActionEvent event) throws IOException {
        App.setRoot("admin-add-cars");
    }

    @FXML
    private void switchToAvailableCars(ActionEvent event) throws IOException {
        App.setRoot("admin-available-cars");
    }

    @FXML
    private void switchToCarsSold(ActionEvent event) throws IOException {
        App.setRoot("admin-cars-sold");
    }

    @FXML
    private void switchToDepositWithdraw(ActionEvent event) throws IOException {
        App.setRoot("admin-deposit-withdraw");
    }

    @FXML
    private void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("admin-view");
    }

    @FXML
    private void switchToSQLView(ActionEvent event) throws IOException {
        App.setRoot("admin-sql");
    }

    @FXML
    private void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }

    private void loadCarPricePerTopSpeedChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        List<XYChart.Data<String, Number>> data = DatabaseHelper.getCarPricePerTopSpeed();
        series.getData().addAll(data);
        carPricePerTopSpeedChart.getData().clear();
        carPricePerTopSpeedChart.getData().add(series);
    }

    private void loadAverageTopSpeedPerFuelTypeChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        List<XYChart.Data<String, Number>> data = DatabaseHelper.getAverageTopSpeedPerFuelType();
        series.getData().addAll(data);
        carAverageTopSpeedPerFuelTypeChart.getData().clear();
        carAverageTopSpeedPerFuelTypeChart.getData().add(series);
    }
}
