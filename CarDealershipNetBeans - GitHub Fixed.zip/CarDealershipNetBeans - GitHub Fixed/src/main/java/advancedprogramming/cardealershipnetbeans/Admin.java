package advancedprogramming.cardealershipnetbeans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.scene.control.Alert;

public class Admin implements Person {
    private static Admin instance;
    private int admin_id = 1;
    private String firstName;
    private String lastName;
    private String username = "Admin";
    private String password = "Admin";
    private static double balance;
    private double moneySpent;
    private double lastDepositValue;
    private Date lastDepositDate;
    private double lastWithdrawValue;
    private Date lastWithdrawDate;
    private double moneyEarned;

    // Private constructor to prevent instantiation from outside
    private Admin() {
        this.balance = getBalance();
    }

    // Method to get the singleton instance of Admin class
    public static Admin getInstance() {
        if (instance == null) {
            instance = new Admin();
        }
        return instance;
    }

    // Getters and Setters for firstName, lastName, username, and password
    @Override
    public String getFirstName() {
        // Retrieve value from database
        firstName = DatabaseHelper.getAdminColumnValue(admin_id, "first_name");
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
        DatabaseHelper.updateAdminColumn(admin_id, "first_name", firstName);
    }

    @Override
    public String getLastName() {
        // Retrieve value from database
        lastName = DatabaseHelper.getAdminColumnValue(admin_id, "last_name");
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
        DatabaseHelper.updateAdminColumn(admin_id, "last_name", lastName);
    }

    public void setBalance(double balance){
        this.balance = balance;
        DatabaseHelper.updateAdminColumn(admin_id, "balance", balance);
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public double getBalance() {
        // Retrieve value from database
        String balanceStr = DatabaseHelper.getAdminColumnValue(admin_id, "balance");
        if (balanceStr != null) {
            try {
                balance = Double.parseDouble(balanceStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return balance;
    }

    // Method to withdraw money from the admin's balance
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            DatabaseHelper.updateAdminColumn(admin_id, "balance", balance);
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Invalid withdrawal amount or insufficient funds.");
        }
    }

    // Method to deposit money into the admin's balance
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            DatabaseHelper.updateAdminColumn(admin_id, "balance", balance);
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public double getMoneySpent() {
        // Retrieve value from database
        String moneySpentStr = DatabaseHelper.getAdminColumnValue(admin_id, "money_spent");
        if (moneySpentStr != null) {
            try {
                moneySpent = Double.parseDouble(moneySpentStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return moneySpent;
    }

    public void setMoneySpent(double moneySpent) {
        this.moneySpent += moneySpent;
        DatabaseHelper.updateAdminColumn(admin_id, "money_spent", moneySpent);
    }

    public double getLastDepositValue() {
        // Retrieve value from database
        String lastDepositValueStr = DatabaseHelper.getAdminColumnValue(admin_id, "last_deposit_value");
        if (lastDepositValueStr != null) {
            try {
                lastDepositValue = Double.parseDouble(lastDepositValueStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastDepositValue;
    }

    public void setLastDepositValue(double lastDepositValue) {
        DatabaseHelper.updateAdminColumn(admin_id, "last_deposit_value", lastDepositValue);
        this.lastDepositValue = lastDepositValue;
    }

    public Date getLastDepositDate() {
        // Retrieve value from database
        String lastDepositDateStr = DatabaseHelper.getAdminColumnValue(admin_id, "last_deposit_date");
        if (lastDepositDateStr != null) {
            try {
                // Parse the string representation of the date into a Date object
                lastDepositDate = new SimpleDateFormat("yyyy-MM-dd").parse(lastDepositDateStr);
            } catch (ParseException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastDepositDate;
    }

    public void setLastDepositDate(Date newLastDepositDate) {
        // Convert java.util.Date to java.sql.Date
        java.sql.Date sqlLastDepositDate = new java.sql.Date(newLastDepositDate.getTime());

        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "last_deposit_date", sqlLastDepositDate);

        this.lastDepositDate = newLastDepositDate;
    }

    public double getLastWithdrawValue() {
        // Retrieve value from database
        String lastWithdrawValueStr = DatabaseHelper.getAdminColumnValue(admin_id, "last_withdraw_value");
        if (lastWithdrawValueStr != null) {
            try {
                lastWithdrawValue = Double.parseDouble(lastWithdrawValueStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastWithdrawValue;
    }

    public void setLastWithdrawDate(Date newLastWithdrawDate) {
        // Convert java.util.Date to java.sql.Date
        java.sql.Date sqlLastWithdrawDate = new java.sql.Date(newLastWithdrawDate.getTime());

        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "last_withdraw_date", sqlLastWithdrawDate);

        this.lastWithdrawDate = newLastWithdrawDate;
    }

    public Date getLastWithdrawDate() {
        // Retrieve value from database
        String lastWithdrawDateStr = DatabaseHelper.getAdminColumnValue(admin_id, "last_withdraw_date");
        if (lastWithdrawDateStr != null) {
            try {
                // Parse the string representation of the date into a Date object
                lastWithdrawDate = new SimpleDateFormat("yyyy-MM-dd").parse(lastWithdrawDateStr);
            } catch (ParseException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastWithdrawDate;
    }

    public void setLastWithdrawValue(double newLastWithdrawValue) {
        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "last_withdraw_value", newLastWithdrawValue);
        this.lastWithdrawValue = newLastWithdrawValue;
    }

    public double getMoneyEarned() {
        // Retrieve value from database
        String moneyEarnedStr = DatabaseHelper.getAdminColumnValue(admin_id, "money_earned");
        if (moneyEarnedStr != null) {
            try {
                moneyEarned = Double.parseDouble(moneyEarnedStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return moneyEarned;
    }

    public void setMoneyEarned(double moneyEarned) {
        this.moneyEarned += moneyEarned;
        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "money_earned", moneyEarned);
    }

    @Override
    public void setUsername(String username) {
        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "username", username);
        this.username = username;
    }

    @Override
    public void setPassword(String password) {
        // Update value in database
        DatabaseHelper.updateAdminColumn(admin_id, "password", password);
        this.password = password;
    }

    public void buyCar(double price) {
        if (balance >= price) {
            setBalance(balance - price);
            setMoneySpent(this.moneySpent + price);
        } else {
            App.showAlert("Error", "Not enough money to buy the car","Add balance to be able to add the car");
        }
    }
}
