package advancedprogramming.cardealershipnetbeans;


import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

public class DatabaseHelper {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/cardealership";
    private static final String DB_USER = "root" ;
    private static final String DB_PASSWORD = ""; // Password Here

    // Method to check if a username already exists in the database
    protected static boolean isUsernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to check if an email already exists in the database
    protected static boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to insert a new user into the database
    protected static void insertUser(String username, String password, String email, String firstName, String lastName) {
        
        String sql = "INSERT INTO users (username, email, password, first_name, last_name) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setString(4, firstName);
            stmt.setString(5, lastName);
            stmt.executeUpdate();
            
            
        } catch (SQLException e) {
            e.printStackTrace();
            
        }
    }

    
    // Method to authenticate a user
    protected static boolean authenticateUser(String username, String password) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    
    
    // Method to authenticate a user
    protected static boolean authenticateAdmin(String username, String password) {
        String sql = "SELECT COUNT(*) FROM admins WHERE username = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    
    
    public static String executeSQL(String command) {
        StringBuilder result = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(command)) {

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columns = metaData.getColumnCount();

            // Append column names to result
            for (int i = 1; i <= columns; i++) {
                result.append(metaData.getColumnName(i)).append("\t");
            }
            result.append("\n");

            // Append query results to result
            while (resultSet.next()) {
                for (int i = 1; i <= columns; i++) {
                    result.append(resultSet.getString(i)).append("\t");
                }
                result.append("\n");
            }
        } catch (SQLException e) {
            result.append("Error executing SQL: ").append(e.getMessage());
        }

        return result.toString();
    }
    
    
    // Method to retrieve user information by username
protected static User getUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        User user =new User();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("user_id");
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    String email = rs.getString("email");
                    String password = rs.getString("password");
                    double balance = rs.getDouble("balance");
                    double moneySpent = rs.getDouble("money_spent");

                    // Create User object with retrieved information

                    user = new User(userId, firstName, lastName, email, password, username);
                    user.setBalance(balance);
                    user.setMoneySpent(moneySpent);
                }
            }
        } catch (SQLException e) {
            App.showAlert("Error", "User not found", "Enter correct user data");
            e.printStackTrace();
        }

        if (user == null) {
            System.out.println("No user found with username: " + username);
        } else {
            System.out.println("User found: " + user.getUsername());
        }

        return user;
    }




    // Method to retrieve user information by username
protected static Admin getAdminByUsername(String username) {
    String sql = "SELECT * FROM admins WHERE username = ?";
    Admin admin = Admin.getInstance();
    
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, username);
        
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
               
                double balance = rs.getDouble("balance");
                admin.setBalance(balance);
                
            }
        }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (admin == null) {
            System.out.println("No Admin found with username: " + username);
        } else {
            System.out.println("Admin found: " + admin.getUsername());
        }

        return admin;
    }

    


    protected static void updateUserColumn(int userId, String columnName, String value) {
        String sql = "UPDATE users SET " + columnName + " = ? WHERE user_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, value);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
        // Method to get a specific column value for a user
    protected static String getUserColumnValue(int userId, String columnName) {
        String value = null;
        String sql = "SELECT " + columnName + " FROM users WHERE user_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    value = rs.getString(columnName);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return value;
    }

    
    protected static void updateUserColumn(int userId, String columnName, Date value) {
    String sql = "UPDATE users SET " + columnName + " = ? WHERE user_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setDate(1, new java.sql.Date(value.getTime()));
        stmt.setInt(2, userId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    protected static void updateUserColumn(int userId, String columnName, double value) {
    String sql = "UPDATE users SET " + columnName + " = ? WHERE user_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setDouble(1, value);
        stmt.setInt(2, userId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    protected static void updateUserColumn(int userId, String columnName, int value) {
    String sql = "UPDATE users SET " + columnName + " = ? WHERE user_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, value);
        stmt.setInt(2, userId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    
    protected static void updateUserColumn(int userId, String columnName, Object value) {
        String sql = "UPDATE users SET " + columnName + " = ? WHERE userId = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (value instanceof java.util.Date) {
                // Convert java.util.Date to java.sql.Date
                java.sql.Date sqlDate = new java.sql.Date(((java.util.Date) value).getTime());
                stmt.setDate(1, sqlDate);
            } else {
                stmt.setObject(1, value);
            }
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    
    

    protected static void updateAdminColumn(int adminId, String columnName, String value) {
        String sql = "UPDATE admins SET " + columnName + " = ? WHERE admin_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, value);
            stmt.setInt(2, adminId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected static void updateAdminColumn(int adminId, String columnName, Date value) {
        String sql = "UPDATE admins SET " + columnName + " = ? WHERE admin_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(value.getTime()));
            stmt.setInt(2, adminId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

protected static void updateAdminColumn(int adminId, String columnName, double value) {
    String sql = "UPDATE admins SET " + columnName + " = ? WHERE admin_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setDouble(1, value);
        stmt.setInt(2, adminId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateAdminColumn(int adminId, String columnName, int value) {
    String sql = "UPDATE admins SET " + columnName + " = ? WHERE admin_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, value);
        stmt.setInt(2, adminId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateAdminColumn(int adminId, String columnName, Object value) {
    String sql = "UPDATE admins SET " + columnName + " = ? WHERE admin_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        if (value instanceof java.util.Date) {
            // Convert java.util.Date to java.sql.Date
            java.sql.Date sqlDate = new java.sql.Date(((java.util.Date) value).getTime());
            stmt.setDate(1, sqlDate);
        } else {
            stmt.setObject(1, value);
        }
        stmt.setInt(2, adminId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static String getAdminColumnValue(int adminId, String columnName) {
    String value = null;
    String sql = "SELECT " + columnName + " FROM admins WHERE admin_id = ?";
    
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, adminId);
        
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                value = rs.getString(columnName);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return value;
}


protected static int countTotalUsers() {
    String sql = "SELECT COUNT(*) AS totalUsers FROM users";
    int totalUsers = 0;
    
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            totalUsers = rs.getInt("totalUsers");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return totalUsers;
}



    // Utility method to create a Car object from a ResultSet
    private static Car createCarFromResultSet(ResultSet rs) throws SQLException {
        int carId = rs.getInt("car_id");
        String make = rs.getString("make");
        String model = rs.getString("model");
        
        int horsepower = rs.getInt("horsepower");
        String fuelType = rs.getString("fuel_type");
        String transmission = rs.getString("transmission");
        int topSpeed = rs.getInt("top_speed");
        double price = rs.getDouble("price");
        int year = rs.getInt("year");
        String color = rs.getString("color");
        boolean sold = rs.getBoolean("sold");
        int ownerId = rs.getInt("owner_id");
        Date dateAdded = rs.getDate("date_added");
        Date dateSold = rs.getDate("date_sold");
        String carType = rs.getString("car_type");
        String photoURL = rs.getString("photo_url");

        return new Car(carId, make, model, horsepower, fuelType, transmission,
                topSpeed, price, year, color, sold, ownerId, dateAdded, dateSold, carType, photoURL);
    }

    // Method to retrieve cars that are sold
    public static List<Car> getSoldCars() {
        List<Car> soldCars = new ArrayList<>();
        String query = "SELECT * FROM cars WHERE sold = 1";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Car car = createCarFromResultSet(rs);
                soldCars.add(car);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return soldCars;
    }

    // Method to retrieve cars that are not sold
    public static List<Car> getUnsoldCars() {
        List<Car> unsoldCars = new ArrayList<>();
        String query = "SELECT * FROM cars WHERE sold = 0";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Car car = createCarFromResultSet(rs);
                unsoldCars.add(car);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return unsoldCars;
    }
    
    
     // Method to retrieve all cars
    public static List<Car> getAllCars() {
        List<Car> cars = new ArrayList<>();
        String query = "SELECT * FROM cars";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Car car = createCarFromResultSet(rs);
                cars.add(car);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cars;
    }
    
        // Method to retrieve cars owned by a specific user
    public static List<Car> getCarsByOwnerId(int ownerId) {
        List<Car> ownedCars = new ArrayList<>();
        String query = "SELECT * FROM cars WHERE owner_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, ownerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Car car = createCarFromResultSet(rs);
                    ownedCars.add(car);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ownedCars;
    }
    
    
    // Method to retrieve cars sorted by price in ascending order
public static List<Car> getCarsSortedByPriceAsc() {
    List<Car> sortedCars = new ArrayList<>();
    String query = "SELECT * FROM cars ORDER BY price ASC";
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            Car car = createCarFromResultSet(rs);
            sortedCars.add(car);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return sortedCars;
}

// Method to retrieve cars sorted by price in descending order
public static List<Car> getCarsSortedByPriceDesc() {
    List<Car> sortedCars = new ArrayList<>();
    String query = "SELECT * FROM cars ORDER BY price DESC";
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            Car car = createCarFromResultSet(rs);
            sortedCars.add(car);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return sortedCars;
}


// Method to retrieve cars sorted by top speed in descending order
public static List<Car> getCarsSortedByTopSpeedDesc() {
    List<Car> sortedCars = new ArrayList<>();
    String query = "SELECT * FROM cars ORDER BY top_speed DESC";
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            Car car = createCarFromResultSet(rs);
            sortedCars.add(car);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return sortedCars;
}

// Method to retrieve cars with a certain car type
public static List<Car> getCarsByCarType(String carType) {
    List<Car> filteredCars = new ArrayList<>();
    String query = "SELECT * FROM cars WHERE car_type = ?";
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, carType);
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Car car = createCarFromResultSet(rs);
                filteredCars.add(car);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return filteredCars;
}

// Method to count the number of not sold cars
    public static int countNotSoldCars() {
        String sql = "SELECT COUNT(*) AS notSoldCars FROM cars WHERE sold = 0";
        int notSoldCarsCount = 0;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                notSoldCarsCount = rs.getInt("notSoldCars");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return notSoldCarsCount;
    }
    
    
    // Method to get the sum of prices of sold cars
    public static double getSumOfSoldCarPrices() {
        String sql = "SELECT SUM(price) AS totalSoldCarPrices FROM cars WHERE sold = 1";
        double totalSoldCarPrices = 0.0;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                totalSoldCarPrices = rs.getDouble("totalSoldCarPrices");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalSoldCarPrices;
    }
    
    
    
    protected static void updateCarColumn(int carId, String columnName, String value) {
    String sql = "UPDATE cars SET " + columnName + " = ? WHERE car_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, value);
        stmt.setInt(2, carId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateCarColumn(int carId, String columnName, Date value) {
    String sql = "UPDATE cars SET " + columnName + " = ? WHERE car_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setDate(1, new java.sql.Date(value.getTime()));
        stmt.setInt(2, carId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateCarColumn(int carId, String columnName, double value) {
    String sql = "UPDATE cars SET " + columnName + " = ? WHERE car_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setDouble(1, value);
        stmt.setInt(2, carId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateCarColumn(int carId, String columnName, int value) {
    String sql = "UPDATE cars SET " + columnName + " = ? WHERE car_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, value);
        stmt.setInt(2, carId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

protected static void updateCarColumn(int carId, String columnName, Object value) {
    String sql = "UPDATE cars SET " + columnName + " = ? WHERE car_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        if (value instanceof java.util.Date) {
            // Convert java.util.Date to java.sql.Date
            java.sql.Date sqlDate = new java.sql.Date(((java.util.Date) value).getTime());
            stmt.setDate(1, sqlDate);
        } else {
            stmt.setObject(1, value);
        }
        stmt.setInt(2, carId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    protected static String getCarColumnValue(int carId, String columnName) {
        String value = null;
        String sql = "SELECT " + columnName + " FROM cars WHERE car_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, carId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    value = rs.getString(columnName);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return value;
    }
    
    // Delete a car from the database
    public static void deleteCar(int carId) {
        String sql = "DELETE FROM cars WHERE car_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, carId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Insert a new car into the database
    public static void insertNewCar(String make, String model, int horsepower, String fuelType,
                                    String transmission, int topSpeed, double price, int year, String color, 
                                    String carType, String photoURL, java.util.Date dateAdded) {
        String sql = "INSERT INTO cars (make, model, horsepower, fuel_type, transmission, top_speed, price, year, color, car_type, photo_url, date_added) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, make);
            stmt.setString(2, model);
            stmt.setInt(3, horsepower);
            stmt.setString(4, fuelType);
            stmt.setString(5, transmission);
            stmt.setInt(6, topSpeed);
            stmt.setDouble(7, price);
            stmt.setInt(8, year);
            stmt.setString(9, color);
            stmt.setString(10, carType);
            stmt.setString(11, photoURL);
            stmt.setDate(12, new java.sql.Date(dateAdded.getTime()));  // Convert java.util.Date to java.sql.Date
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public static List<PieChart.Data> getCarTypeStatistics() {
        List<PieChart.Data> carTypeData = new ArrayList<>();
        String sql = "SELECT car_type, COUNT(*) AS count FROM cars GROUP BY car_type";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String carType = rs.getString("car_type");
                int count = rs.getInt("count");
                carTypeData.add(new PieChart.Data(carType, count));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return carTypeData;
    }
     
     
     public static List<XYChart.Data<String, Double>> getMoneyEarnedPerCarType() {
        List<XYChart.Data<String, Double>> data = new ArrayList<>();
        String query = "SELECT car_type, SUM(price) AS total_earned FROM cars WHERE sold = 1 GROUP BY car_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("car_type"), rs.getDouble("total_earned")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
     
     // Method to get money earned per fuel type
    public static List<XYChart.Data<String, Double>> getMoneyEarnedPerFuelType() {
        List<XYChart.Data<String, Double>> data = new ArrayList<>();
        String query = "SELECT fuel_type, SUM(price) AS total_earned FROM cars WHERE sold = 1 GROUP BY fuel_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("fuel_type"), rs.getDouble("total_earned")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    // Method to get money earned per transmission type
    public static List<XYChart.Data<String, Double>> getMoneyEarnedPerTransmission() {
        List<XYChart.Data<String, Double>> data = new ArrayList<>();
        String query = "SELECT transmission, SUM(price) AS total_earned FROM cars WHERE sold = 1 GROUP BY transmission";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("transmission"), rs.getDouble("total_earned")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    
    // Method to get average car price
    public static double getAverageCarPrice() {
        String query = "SELECT AVG(price) AS average_price FROM cars WHERE sold = 0";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getDouble("average_price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Method to get average car year
    public static double getAverageCarYear() {
        String query = "SELECT AVG(year) AS average_year FROM cars WHERE sold = 0";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getDouble("average_year");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Method to get car count by make
    public static List<PieChart.Data> getCarCountByMake() {
        List<PieChart.Data> data = new ArrayList<>();
        String query = "SELECT make, COUNT(*) AS count FROM cars WHERE sold = 0 GROUP BY make";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new PieChart.Data(rs.getString("make"), rs.getInt("count")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    // Method to get car count by fuel type
    public static List<PieChart.Data> getCarCountByFuelType() {
        List<PieChart.Data> data = new ArrayList<>();
        String query = "SELECT fuel_type, COUNT(*) AS count FROM cars WHERE sold = 0 GROUP BY fuel_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new PieChart.Data(rs.getString("fuel_type"), rs.getInt("count")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    
    
    // Method to get car price per top speed
    public static List<XYChart.Data<String, Number>> getCarPricePerTopSpeed() {
        List<XYChart.Data<String, Number>> data = new ArrayList<>();
        String query = "SELECT top_speed, AVG(price) AS avg_price FROM cars GROUP BY top_speed";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(String.valueOf(rs.getInt("top_speed")), rs.getDouble("avg_price")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    
    

    // Method to get average top speed per fuel type
    public static List<XYChart.Data<String, Number>> getAverageTopSpeedPerFuelType() {
        List<XYChart.Data<String, Number>> data = new ArrayList<>();
        String query = "SELECT fuel_type, AVG(top_speed) AS avg_top_speed FROM cars GROUP BY fuel_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("fuel_type"), rs.getDouble("avg_top_speed")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    

    // Method to retrieve cars sold per car type
    public static List<XYChart.Data<String, Number>> getCarsSoldPerCarType() {
        List<XYChart.Data<String, Number>> data = new ArrayList<>();
        String query = "SELECT car_type, COUNT(*) AS total_sold FROM cars WHERE sold = 1 GROUP BY car_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("car_type"), rs.getInt("total_sold")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    // Method to retrieve profits per date
    public static List<XYChart.Data<String, Number>> getProfitsPerDate() {
        List<XYChart.Data<String, Number>> data = new ArrayList<>();
        String query = "SELECT date_sold, SUM(price) AS total_profit FROM cars WHERE sold = 1 GROUP BY date_sold";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("date_sold"), rs.getDouble("total_profit")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    
    // Method to retrieve profits per car type
    public static List<XYChart.Data<String, Number>> getProfitsPerCarType() {
        List<XYChart.Data<String, Number>> data = new ArrayList<>();
        String query = "SELECT car_type, SUM(price) AS total_profit FROM cars WHERE sold = 1 GROUP BY car_type";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                data.add(new XYChart.Data<>(rs.getString("car_type"), rs.getDouble("total_profit")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    


}


    




    

