
package advancedprogramming.cardealershipnetbeans;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


public class CarCardController {
    //////card code
    @FXML
    private Label carNameAndPriceLabel;

    @FXML
    private AnchorPane cardAnchorPane;

    @FXML
     ImageView cardCarImage;
    
    // Method to set car details
    public void setCarDetails(Car car) {
        carNameAndPriceLabel.setText(car.getMake() + " " + car.getModel() + " - $" + car.getPrice());
        // Other details can be set similarly
    }
    
    
}
