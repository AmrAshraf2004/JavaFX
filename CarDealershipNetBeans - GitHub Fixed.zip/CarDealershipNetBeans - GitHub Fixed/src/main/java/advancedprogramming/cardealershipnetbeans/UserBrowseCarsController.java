package advancedprogramming.cardealershipnetbeans;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class UserBrowseCarsController implements Initializable {

    private static final int CARD_PREF_WIDTH = 260; // Preferred width of each car card
    private static final int CARD_PREF_HEIGHT = 160; // Preferred height of each car card

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Get the User who logged in
        LoginController loginController = LoginController.getInstance();
        this.user = loginController.user;
        // Initialize UI elements until the refresh button is clicked
        updateInfo();

        // Add a listener to the width property of the ScrollPane to adjust the number of columns dynamically
        carBrowseScrollPane.widthProperty().addListener((observable, oldValue, newValue) -> loadCarCards());

        loadCarCards();
    }

    // Method to update user information in the UI
    public void updateInfo() {
        name_label.setText(user.getFirstName());
    }

    private User user;
    private Car selectedCar;

    @FXML
    private Button add_balance_btn;

    @FXML
    private Button browse_cars_btn;

    @FXML
    private Button cars_owned_btn;

    @FXML
    private Button home_btn;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label name_label;

    @FXML
    private TextArea CarDetailsTextArea;

    @FXML
    private Button buy_car_btn;

    @FXML
    private ScrollPane carBrowseScrollPane;

    @FXML
    private GridPane carCardsGridPane;

    @FXML
    private Button refresh_btn;

    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }

    @FXML
    void switchToAddBalance(ActionEvent event) throws IOException {
        App.setRoot("user-add-balance");
    }

    @FXML
    void switchToBrowseCars(ActionEvent event) throws IOException {
        App.setRoot("user-browse-cars");
    }

    @FXML
    void switchToCarsOwned(ActionEvent event) throws IOException {
        App.setRoot("user-cars-owned");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("user-view");
    }

    @FXML
    void refreshCars(ActionEvent event) throws Exception {
        loadCarCards();
    }

    private void loadCarCards() {
        carCardsGridPane.getChildren().clear(); // Clear any existing cards
        carCardsGridPane.getColumnConstraints().clear(); // Clear existing column constraints
        carCardsGridPane.getRowConstraints().clear(); // Clear existing row constraints

        double scrollPaneWidth = carBrowseScrollPane.getWidth();
        int numColumns = (int) (scrollPaneWidth / CARD_PREF_WIDTH); // Calculate number of columns based on ScrollPane width
        numColumns = numColumns > 0 ? numColumns : 1; // Ensure at least one column

        // Define column constraints
        for (int i = 0; i < numColumns; i++) {
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPrefWidth(CARD_PREF_WIDTH);
            carCardsGridPane.getColumnConstraints().add(colConst);
        }

        List<Car> cars = DatabaseHelper.getUnsoldCars(); // Load cars from the database
        int row = 0;
        int col = 0;

        for (Car car : cars) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("car-card.fxml"));
                AnchorPane carCard = loader.load(); // Load car card layout
                CarCardController controller = loader.getController();
                controller.setCarDetails(car);

                // Set image (if you have an ImageView in your CarCard.fxml)
                Image image = new Image(car.getPhotoURL());
                controller.cardCarImage.setImage(image);

                carCardsGridPane.add(carCard, col, row);
                col++;
                if (col == numColumns) { // Move to the next row after filling the columns
                    col = 0;
                    row++;
                }

                // Add event handler for clicking the card
                carCard.setOnMouseClicked(event -> showCarDetails(car));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Add row constraints for each row
        for (int i = 0; i <= row; i++) {
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPrefHeight(CARD_PREF_HEIGHT);
            carCardsGridPane.getRowConstraints().add(rowConst);
        }
    }

    // Method to show car details in the text area
    private void showCarDetails(Car car) {
        selectedCar = car;
        CarDetailsTextArea.setText(car.getUserFriendlyDetails());
    }

    @FXML
    void purchaseCar(ActionEvent event) { // Buying selected car method
        if (selectedCar != null && !selectedCar.isSold() && user.getBalance() >= selectedCar.getPrice()) {
            boolean confirmed = App.showConfirmationDialog("Confirm Purchase", "Are you sure you want to purchase this car?", "Make: " + selectedCar.getMake() + "\nModel: " + selectedCar.getModel() + "\nPrice: $" + selectedCar.getPrice());
            if (confirmed) {
                try {
                    selectedCar.buyCar(user); // Method in Car class
                    loadCarCards(); // Refresh the car cards
                    CarDetailsTextArea.clear();
                    App.showSuccessAlert("Purchase Successful", "Car Purchase", "You have successfully purchased the car.");
                } catch (Exception e) {
                    e.printStackTrace();
                    App.showAlert("Error", "Purchase Failed", "An error occurred while purchasing the car.");
                }
            }
        } else {
            App.showAlert("Error", "Purchase Failed", "Insufficient balance or car already sold.");
        }
    }
}
