

package advancedprogramming.cardealershipnetbeans;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class AdminSQLController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        AdminLoginController adminLoginController = AdminLoginController.getInstance();
        this.admin = adminLoginController.admin;
    }
    
    Admin admin;


    @FXML
    private Button availableCars_btn;

    @FXML
    private Button cars_sold_btn;

    @FXML
    private Button deposit_withdraw_btn;

    @FXML
    private Button go_add_cars_btn;

    @FXML
    private Button home_btn;


    @FXML
    private AnchorPane home_form;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button sql_btn;


    @FXML
    void switchToAddCars(ActionEvent event) throws IOException {
        App.setRoot("admin-add-cars");
    }

    @FXML
    void switchToAvailableCars(ActionEvent event) throws IOException {
        App.setRoot("admin-available-cars");
    }

    @FXML
    void switchToCarsSold(ActionEvent event) throws IOException {
        App.setRoot("admin-cars-sold");
    }

    @FXML
    void switchToDepositWithdraw(ActionEvent event) throws IOException {
        App.setRoot("admin-deposit-withdraw");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("admin-view");
    }

    @FXML
    void switchToSQLView(ActionEvent event) throws IOException {
        App.setRoot("admin-sql");
    }
    
    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900,600);
        App.setRoot("Welcome");
    }
    
    @FXML
    private Button execute_btn;

    @FXML
    private TextField sql_commands_txt;

    @FXML
    private TextArea sql_results;

    @FXML
    void executeSQL(ActionEvent event) {
        String command = sql_commands_txt.getText();
        String result = DatabaseHelper.executeSQL(command);
        sql_results.setText(result);
    }
    
    
}
