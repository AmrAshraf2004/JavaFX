package advancedprogramming.cardealershipnetbeans;



import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class AdminLoginController implements Initializable {

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    Admin admin;
    
    @FXML
    private Button btn_go_login;

    @FXML
    private PasswordField password_txt_field;

    @FXML
    private Button userButton;

    @FXML
    private TextField username_txt_field;

    @FXML
    void switchToLogin(ActionEvent event) throws IOException {
        // Perform login authentication here
        String username = username_txt_field.getText();
        String password = password_txt_field.getText();
        
        // Retrieve user from database by username
        Admin admin = DatabaseHelper.getAdminByUsername(username);
        
        // Check username and password against database
        boolean loginSuccessful = DatabaseHelper.authenticateAdmin(username, password);
        
        if (loginSuccessful) {
            
            this.admin = admin;
            this.instance= new AdminLoginController();
            this.instance.admin = admin;
            
            App.changeSceneSize(1130,650);
            App.setRoot("admin-view");
            
            
        } else {
            // Show error message
            App.showAlert("Login Error", "Invalid credentials", "Please check your username and password.");
        }
    }
    
    // This is to have a template to all classes to get the current Admin that is running program
    private static AdminLoginController instance;

    public static AdminLoginController getInstance() { // All Admin Controllers call it to retrieve and modify admin information
        return instance;
    }
    

    @FXML
    void switchToUserView(ActionEvent event) throws IOException {
        App.setRoot("login");
    }
}

