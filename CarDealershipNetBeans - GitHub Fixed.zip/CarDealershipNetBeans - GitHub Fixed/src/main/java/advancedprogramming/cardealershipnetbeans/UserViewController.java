package advancedprogramming.cardealershipnetbeans;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UserViewController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        //Get the User that logged in
        LoginController loginController = LoginController.getInstance();
        this.user = loginController.user;
        // Initialize the thread with the user and controller
        UserThread updateThread = new UserThread(this);

        // Start the thread
        updateThread.start();

        // Initialize the photo display
        initializePhoto();
    }

    User user;

    // Method to update user information in the UI with Thread
    public void updateInfo() {
        name_label.setText(user.getFirstName());
        total_balance_label.setText("$" + user.getBalance());
        money_spent_label.setText("$" + user.getMoneySpent());
        cars_owned_label.setText(String.valueOf(DatabaseHelper.getCarsByOwnerId(user.getUserId()).size()));
        showNextPhoto();
    }

    @FXML
    private Button add_balance_btn;

    @FXML
    private Button goBackPhoto;

    @FXML
    private Button goNextPhoto;

    @FXML
    private ImageView imageViewHome;

    @FXML
    private Button browse_cars_btn;

    @FXML
    private Button cars_owned_btn;

    @FXML
    private Label cars_owned_label;

    @FXML
    private Button home_btn;

    @FXML
    private AnchorPane home_form;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label money_spent_label;

    @FXML
    private Label name_label;

    @FXML
    private Label total_balance_label;

    @FXML
    private Button next_photo_btn;

    @FXML
    private Button prev_photo_btn;

    private Image[] photos;
    private int currentPhotoIndex = 0;
    

    //method to start the photo slideshow in home screen
    private void initializePhoto() {
        photos = new Image[]{
            new Image(getClass().getResource("/advancedprogramming/cardealershipnetbeans/images/photo8.jpg").toExternalForm()),
            new Image(getClass().getResource("/advancedprogramming/cardealershipnetbeans/images/photo5.png").toExternalForm()),
            new Image(getClass().getResource("/advancedprogramming/cardealershipnetbeans/images/photo6.jpg").toExternalForm()),
            new Image(getClass().getResource("/advancedprogramming/cardealershipnetbeans/images/photo7.jpg").toExternalForm()),
            new Image(getClass().getResource("/advancedprogramming/cardealershipnetbeans/images/photo3.jpg").toExternalForm())
        };

        if (photos.length > 0) {
            imageViewHome.setImage(photos[0]);
        }

        
    }

    private void showNextPhoto() {
        currentPhotoIndex = (currentPhotoIndex + 1) % photos.length;
        imageViewHome.setImage(photos[currentPhotoIndex]);
    }

    private void showPreviousPhoto() {
        currentPhotoIndex = (currentPhotoIndex - 1 + photos.length) % photos.length;
        imageViewHome.setImage(photos[currentPhotoIndex]);
    }

    @FXML
    private void nextPhoto(ActionEvent event) {
        showNextPhoto();
    }

    @FXML
    private void prevPhoto(ActionEvent event) {
        showPreviousPhoto();
    }

    @FXML
    void switchToAddBalance(ActionEvent event) throws IOException {
        App.setRoot("user-add-balance");
    }

    @FXML
    void switchToBrowseCars(ActionEvent event) throws IOException {
        App.setRoot("user-browse-cars");
    }

    @FXML
    void switchToCarsOwned(ActionEvent event) throws IOException {
        App.setRoot("user-cars-owned");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("user-view");
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }
}
