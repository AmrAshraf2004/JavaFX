package advancedprogramming.cardealershipnetbeans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Car {
    private int carId;
    private String make;
    private String model;
    private int horsepower;
    private String fuelType;
    private String transmission;
    private int topSpeed;
    private double price;
    private int year;
    private String color;
    private boolean sold;
    private int ownerId;
    private Date dateAdded;
    private Date dateSold;
    private String carType;
    private String photoURL;

    // Constructor
    public Car(int carId, String make, String model, int horsepower, String fuelType,
               String transmission, int topSpeed, double price, int year, String color, boolean sold,
               int ownerId, Date dateAdded, Date dateSold, String carType, String photoURL) {
        this.carId = carId;
        this.make = make;
        this.model = model;
        this.horsepower = horsepower;
        this.fuelType = fuelType;
        this.transmission = transmission;
        this.topSpeed = topSpeed;
        this.price = price;
        this.year = year;
        this.color = color;
        this.sold = sold;
        this.ownerId = ownerId;
        this.dateAdded = dateAdded;
        this.dateSold = dateSold;
        this.carType = carType;
        this.photoURL = photoURL;
    }

    // Static method to insert a new car into the database
    public static void insertNewCar(String make, String model, int horsepower, String fuelType,
                                    String transmission, int topSpeed, double price, int year, String color, 
                                    String carType, String photoURL, Date dateAdded) {
        DatabaseHelper.insertNewCar(make, model, horsepower, fuelType, transmission, topSpeed, price, year, color, carType, photoURL, dateAdded);
    }

    // Static method to update car attributes in the database
    public static void updateCar(int carId, String columnName, Object value) {
        DatabaseHelper.updateCarColumn(carId, columnName, value);
    }

    // Static method to delete a car from the database
    public static void deleteCar(int carId) {
        DatabaseHelper.deleteCar(carId);
    }

    // Getters and setters
    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
        DatabaseHelper.updateCarColumn(carId, "car_id", carId);
    }

    public String getMake() {
        make = DatabaseHelper.getCarColumnValue(carId, "make");
        return make;
    }

    public void setMake(String make) {
        this.make = make;
        DatabaseHelper.updateCarColumn(carId, "make", make);
    }

    public String getModel() {
        model = DatabaseHelper.getCarColumnValue(carId, "model");
        return model;
    }

    public void setModel(String model) {
        this.model = model;
        DatabaseHelper.updateCarColumn(carId, "model", model);
    }

    public int getHorsepower() {
        String horsepowerStr = DatabaseHelper.getCarColumnValue(carId, "horsepower");
        if (horsepowerStr != null) {
            try {
                horsepower = Integer.parseInt(horsepowerStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
        DatabaseHelper.updateCarColumn(carId, "horsepower", horsepower);
    }

    public String getFuelType() {
        fuelType = DatabaseHelper.getCarColumnValue(carId, "fuel_type");
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
        DatabaseHelper.updateCarColumn(carId, "fuel_type", fuelType);
    }

    public String getTransmission() {
        transmission = DatabaseHelper.getCarColumnValue(carId, "transmission");
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
        DatabaseHelper.updateCarColumn(carId, "transmission", transmission);
    }

    public int getTopSpeed() {
        String topSpeedStr = DatabaseHelper.getCarColumnValue(carId, "top_speed");
        if (topSpeedStr != null) {
            try {
                topSpeed = Integer.parseInt(topSpeedStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return topSpeed;
    }

    public void setTopSpeed(int topSpeed) {
        this.topSpeed = topSpeed;
        DatabaseHelper.updateCarColumn(carId, "top_speed", topSpeed);
    }

    public double getPrice() {
        String priceStr = DatabaseHelper.getCarColumnValue(carId, "price");
        if (priceStr != null) {
            try {
                price = Double.parseDouble(priceStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
        DatabaseHelper.updateCarColumn(carId, "price", price);
    }

    public int getYear() {
        String yearStr = DatabaseHelper.getCarColumnValue(carId, "year");
        if (yearStr != null) {
            try {
                year = Integer.parseInt(yearStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return year;
    }

    public void setYear(int year) {
        this.year = year;
        DatabaseHelper.updateCarColumn(carId, "year", year);
    }

    public String getColor() {
        color = DatabaseHelper.getCarColumnValue(carId, "color");
        return color;
    }

    public void setColor(String color) {
        this.color = color;
        DatabaseHelper.updateCarColumn(carId, "color", color);
    }

    public boolean isSold() {
        String soldStr = DatabaseHelper.getCarColumnValue(carId, "sold");
        if (soldStr != null) {
            sold = Boolean.parseBoolean(soldStr);
        }
        return sold;
    }

    public void setSold(boolean sold) {
        this.sold = sold;
        DatabaseHelper.updateCarColumn(carId, "sold", sold);
    }

    public int getOwnerId() {
        String ownerIdStr = DatabaseHelper.getCarColumnValue(carId, "owner_id");
        if (ownerIdStr != null) {
            try {
                ownerId = Integer.parseInt(ownerIdStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
        DatabaseHelper.updateCarColumn(carId, "owner_id", ownerId);
    }

    public Date getDateAdded() {
        String dateAddedStr = DatabaseHelper.getCarColumnValue(carId, "date_added");
        if (dateAddedStr != null) {
            try {
                dateAdded = new SimpleDateFormat("yyyy-MM-dd").parse(dateAddedStr);
            } catch (ParseException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        java.sql.Date sqlDateAdded = new java.sql.Date(dateAdded.getTime());
        this.dateAdded = dateAdded;
        DatabaseHelper.updateCarColumn(carId, "date_added", sqlDateAdded);
    }

    public Date getDateSold() {
        String dateSoldStr = DatabaseHelper.getCarColumnValue(carId, "date_sold");
        if (dateSoldStr != null) {
            try {
                dateSold = new SimpleDateFormat("yyyy-MM-dd").parse(dateSoldStr);
            } catch (ParseException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return dateSold;
    }

    public void setDateSold(Date dateSold) {
        java.sql.Date sqlDateSold = new java.sql.Date(dateSold.getTime());
        this.dateSold = dateSold;
        DatabaseHelper.updateCarColumn(carId, "date_sold", sqlDateSold);
    }

    public String getCarType() {
        carType = DatabaseHelper.getCarColumnValue(carId, "car_type");
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
        DatabaseHelper.updateCarColumn(carId, "car_type", carType);
    }

    public String getPhotoURL() {
        photoURL = DatabaseHelper.getCarColumnValue(carId, "photo_url");
        return photoURL;
    }

    public void setPhotoURL(String photoURL) {
        this.photoURL = photoURL;
        DatabaseHelper.updateCarColumn(carId, "photo_url", photoURL);
    }

    public boolean buyCar(User user) {
        if (!this.sold && user.getBalance() >= this.price) {
            // Deduct the car price from the user's balance
            user.setBalance(user.getBalance() - this.price);
            user.setMoneySpent(user.getMoneySpent() + this.price);

            // Update car ownership
            this.ownerId = user.getUserId();
            this.sold = true;
            this.dateSold = new Date();

            // Update values in the database
            DatabaseHelper.updateCarColumn(this.carId, "owner_id", this.ownerId);
            DatabaseHelper.updateCarColumn(this.carId, "sold", true);
            DatabaseHelper.updateCarColumn(this.carId, "date_sold", new java.sql.Date(this.dateSold.getTime()));

            // Retrieve Admin instance
            Admin admin = Admin.getInstance();
            // Update Admin's money earned and balance
            admin.setMoneyEarned(admin.getMoneyEarned() + this.price);
            admin.setBalance(admin.getBalance() + this.price);

            return true;
        } else {
            throw new IllegalStateException("Car is already sold or user has insufficient balance.");
        }
    }

    public String getUserFriendlyDetails() {
        return "Make: " + make + "\n" +
               "Model: " + model + "\n" +
               "Horsepower: " + horsepower + "\n" +
               "Fuel Type: " + fuelType + "\n" +
               "Transmission: " + transmission + "\n" +
               "Top Speed: " + topSpeed + " km/h\n" +
               "Price: $" + price + "\n" +
               "Year: " + year + "\n" +
               "Color: " + color + "\n" +
               "Car Type: " + carType + "\n";
    }

    // Method to return all details about the car
    public String getAllDetails() {
        return "Car ID: " + carId + "\n" +
               "Make: " + make + "\n" +
               "Model: " + model + "\n" +
               "Horsepower: " + horsepower + "\n" +
               "Fuel Type: " + fuelType + "\n" +
               "Transmission: " + transmission + "\n" +
               "Top Speed: " + topSpeed + " km/h\n" +
               "Price: $" + price + "\n" +
               "Year: " + year + "\n" +
               "Color: " + color + "\n" +
               "Sold: " + sold + "\n" +
               "Owner ID: " + ownerId + "\n" +
               "Date Added: " + dateAdded + "\n" +
               "Date Sold: " + dateSold + "\n" +
               "Car Type: " + carType + "\n" +
               "Photo URL: " + photoURL + "\n";
    }
}
