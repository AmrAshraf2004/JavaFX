
package advancedprogramming.cardealershipnetbeans;

import javafx.application.Platform;

public class AdminThread<T> extends Thread { // Thread to Update UI Elements in all Admin Controllers At Once using Generics
    
    private T controller;
    private boolean running;

    public AdminThread(T controller) {
        
        this.controller = controller;
        this.running = true;
    }

    @Override
    public void run() {
        while (running) {
            try {
                // Update UI with admin's information
                Platform.runLater(() -> {
                    if (controller instanceof AdminBalanceController) {
                        ((AdminBalanceController) controller).updateInfo();
                    } else if (controller instanceof AdminCarsSoldController) {
                        ((AdminCarsSoldController) controller).updateInfo();
                    }
                    else if (controller instanceof AdminViewController) {
                        ((AdminViewController) controller).updateInfo();
                    }
                    else if (controller instanceof AdminCarsSoldController) {
                        ((AdminCarsSoldController) controller).updateInfo();
                    }
                    else if (controller instanceof AdminAvailableCarsController) {
                        ((AdminAvailableCarsController) controller).updateInfo();
                    }
                    else if(controller instanceof AdminAddCarsController) {
                        ((AdminAddCarsController)controller).updateInfo();
                    }
                    
                });

                // Sleep for a certain interval (5 seconds)
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void stopThread() {
        running = false;
    }
}

