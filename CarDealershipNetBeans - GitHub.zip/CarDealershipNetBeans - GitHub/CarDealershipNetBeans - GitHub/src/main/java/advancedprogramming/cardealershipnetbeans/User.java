package advancedprogramming.cardealershipnetbeans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class User implements Person {
    
    public static int totalCustomers;
    public int userId;
    public String firstName;
    public String lastName;
    public String email;
    public String password;
    public String username;
    public double balance;
    public double moneySpent;
    public double lastDepositValue;
    public Date lastDepositDate;

    // Constructors
    public User() {
        
    }
    
    public User(int userId, String firstName, String lastName, String email, String password, String username) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.username = username;
    }
    
    public static int getTotalCustomers(){
       return totalCustomers; 
    }
    
    public static void setTotalCustomers(){
        totalCustomers = DatabaseHelper.countTotalUsers();
        
    }
    
    // Setters

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public void setFirstName(String firstName) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "first_name", firstName);
        this.firstName = firstName;
    }

    @Override
    public void setLastName(String lastName) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "last_name", lastName);
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "email", email);
        this.email = email;
    }

    @Override
    public void setPassword(String password) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "password", password);
        this.password = password;
    }

    @Override
    public void setUsername(String username) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "username", username);
        this.username = username;
    }

    public void setBalance(double balance) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "balance", balance);
        this.balance = balance;
    }

    public void setMoneySpent(double moneySpent) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "money_spent", moneySpent);
        this.moneySpent = moneySpent;
    }

    public void setLastDepositValue(double lastDepositValue) {
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "last_deposit_value", lastDepositValue);
        this.lastDepositValue = lastDepositValue;
    }

    public void setLastDepositDate(Date lastDepositDate) {
        // Convert java.util.Date to java.sql.Date
        java.sql.Date sqlLastDepositDate = new java.sql.Date(lastDepositDate.getTime());
        
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "last_deposit_date", sqlLastDepositDate);
        
        this.lastDepositDate = lastDepositDate;
    }

    
    // Getters

    public int getUserId() {
        return userId;
    }

    @Override
    public String getFirstName() {
        // Retrieve value from database if not already set
        if (firstName == null) {
            firstName = (String) DatabaseHelper.getUserColumnValue(userId, "first_name");
        }
        return firstName;
    }

    @Override
    public String getLastName() {
        // Retrieve value from database if not already set
        if (lastName == null) {
            lastName = (String) DatabaseHelper.getUserColumnValue(userId, "last_name");
        }
        return lastName;
    }

    public String getEmail() {
        // Retrieve value from database if not already set
        if (email == null) {
            email = (String) DatabaseHelper.getUserColumnValue(userId, "email");
        }
        return email;
    }

    @Override
    public String getPassword() {
        // Retrieve value from database if not already set
        if (password == null) {
            App.showAlert("ERROR", "User does not exist", "Enter Correct User or Signup");
            password = (String) DatabaseHelper.getUserColumnValue(userId, "password");
        }
        return password;
    }

    @Override
    public String getUsername() {
        // Retrieve value from database if not already set
        if (username == null) {
            username = (String) DatabaseHelper.getUserColumnValue(userId, "username");
        }
        return username;
    }

    public double getBalance() {
        String balanceStr = DatabaseHelper.getUserColumnValue(userId, "balance");
        if (balanceStr != null) {
            try {
                balance = Double.parseDouble(balanceStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return balance;
    }

    public double getMoneySpent() {
        String moneySpentStr = DatabaseHelper.getUserColumnValue(userId, "money_spent");
        if (moneySpentStr != null) {
            try {
                moneySpent = Double.parseDouble(moneySpentStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return moneySpent;
    }

    public double getLastDepositValue() {
        String lastDepositValueStr = DatabaseHelper.getUserColumnValue(userId, "last_deposit_value");
        if (lastDepositValueStr != null) {
            try {
                lastDepositValue = Double.parseDouble(lastDepositValueStr);
            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastDepositValue;
    }


    public Date getLastDepositDate() {
        String lastDepositDateStr = DatabaseHelper.getUserColumnValue(userId, "last_deposit_date");
        Date lastDepositDate = null;
        if (lastDepositDateStr != null) {
            try {
                // Parse the string representation of the date into a Date object
                lastDepositDate = new SimpleDateFormat("yyyy-MM-dd").parse(lastDepositDateStr);
            } catch (ParseException e) {
                e.printStackTrace(); // Handle parsing errors
            }
        }
        return lastDepositDate;
    }

    
    public void addUserBalance(double addedBalance){
        
        this.balance += addedBalance;
        // Update value in database
        DatabaseHelper.updateUserColumn(userId, "balance", balance);
        
    }

}

