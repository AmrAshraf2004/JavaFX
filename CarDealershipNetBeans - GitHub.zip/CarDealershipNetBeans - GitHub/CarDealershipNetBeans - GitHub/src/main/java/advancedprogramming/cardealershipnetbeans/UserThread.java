package advancedprogramming.cardealershipnetbeans;


import javafx.application.Platform;

public class UserThread<T> extends Thread {
    
    //Thread to automatically update UI elements in all UserControllers At Once using generics
    
    private T controller;
    private boolean running;

    public UserThread(T controller) {
        this.controller = controller;
        this.running = true;
    }

    @Override
    public void run() {
        while (running) {
            try {
                // Update UI with user's information
                Platform.runLater(() -> {
                    if (controller instanceof UserViewController) {
                        ((UserViewController) controller).updateInfo();
                    } else if (controller instanceof UserBrowseCarsController) {
                        ((UserBrowseCarsController) controller).updateInfo();
                    } else if (controller instanceof UserCarsOwnedController) {
                        ((UserCarsOwnedController) controller).updateInfo();
                    } else if (controller instanceof UserAddBalanceController) {
                        ((UserAddBalanceController) controller).updateInfo();
                    }
                    
                });

                // Sleep for a certain interval (5 seconds)
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void stopThread() {
        running = false;
    }
}

