package advancedprogramming.cardealershipnetbeans;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import java.util.Date;

public class UserAddBalanceController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        //Get the User who logged in
        LoginController loginController = LoginController.getInstance();
        this.user = loginController.user;
        // Initialize the thread with the user and controller
        UserThread updateThread = new UserThread(this);

        // Start the thread
        updateThread.start();
    }

    User user;

    // Method to update user information in the UI
    public void updateInfo() {
        name_label.setText(user.getFirstName());
        total_balance_label.setText("$"+String.valueOf(user.getBalance()));
        money_spent_label.setText("$"+String.valueOf(user.getMoneySpent()));

        last_deposit_date_label.setText(String.valueOf(user.getLastDepositDate()));
        last_deposit_value_label.setText("$"+String.valueOf(user.getLastDepositValue()));
    }

    @FXML
    private TextField balanceTextField;

    @FXML
    private TextField cvvTextField;

    @FXML
    private TextField cardNumberTextField;
    
    @FXML
    private TextField expiryDateTextField;

    @FXML
    private Button add_balance_btn;

    @FXML
    private Button browse_cars_btn;

    @FXML
    private Button cars_owned_btn;

    @FXML
    private Button home_btn;

    @FXML
    private AnchorPane home_form;

    @FXML
    private Label last_deposit_date_label;

    @FXML
    private Label last_deposit_value_label;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label money_spent_label;

    @FXML
    private Label name_label;

    @FXML
    private Label status_label_failure;

    @FXML
    private Label status_label_success;

    @FXML
    private Label tansaction_label;

    @FXML
    private Label total_balance_label;

    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }

    @FXML
void addBalance(ActionEvent event) {
    String cardNumber = cardNumberTextField.getText();
    String expirationDate = expiryDateTextField.getText();
    String cvv = cvvTextField.getText();
    double balance;

    try {
        balance = Double.parseDouble(balanceTextField.getText());
    } catch (NumberFormatException e) {
        App.showAlert("Invalid Input", "Please enter a valid balance amount.", "");
        return;
    }

    if (Utils.validateCardInfo(cardNumber, expirationDate, cvv)) {
        boolean confirmed = App.showConfirmationDialog("Confirm Deposit", "Confirm Balance Addition", "Are you sure you want to add this balance? This action cannot be undone.");

        if (confirmed) {
            // Perform actions if card information is valid and user confirms
            user.setLastDepositDate(new Date());
            user.setLastDepositValue(balance);
            user.addUserBalance(balance);

            tansaction_label.setText("Transaction Successful");
            status_label_success.setText("Success");
            status_label_failure.setText("");
        } else {
            // User cancelled the operation
            tansaction_label.setText("Transaction Cancelled");
            status_label_failure.setText("Cancelled");
            status_label_success.setText("");
        }
    } else {
        // Display error message if card information is invalid
        App.showAlert("Failure", "Invalid parameters", "Please try again");
        tansaction_label.setText("Transaction Failed");
        status_label_failure.setText("Failure");
        status_label_success.setText("");
    }
}


    @FXML
    void switchToAddBalance(ActionEvent event) throws IOException {
        App.setRoot("user-add-balance");
    }

    @FXML
    void switchToBrowseCars(ActionEvent event) throws IOException {
        App.setRoot("user-browse-cars");
    }

    @FXML
    void switchToCarsOwned(ActionEvent event) throws IOException {
        App.setRoot("user-cars-owned");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        
        App.setRoot("user-view");
    }

}

