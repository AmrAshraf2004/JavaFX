
package advancedprogramming.cardealershipnetbeans;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AdminAvailableCarsController implements Initializable {

    private Admin admin;

    @FXML
    private Button availableCars_btn;
    @FXML
    private Button cars_sold_btn;
    @FXML
    private Button deposit_withdraw_btn;
    @FXML
    private Button go_add_cars_btn;
    @FXML
    private Button home_btn;
    @FXML
    private AnchorPane home_form;
    @FXML
    private Button logoutBtn;
    @FXML
    private AnchorPane main_form;
    @FXML
    private Button sql_btn;

    @FXML
    private TableView<Car> cars_available_table;
    @FXML
    private TableColumn<Car, Integer> car_id_column;
    @FXML
    private TableColumn<Car, String> car_type_column;
    @FXML
    private TableColumn<Car, String> color_column;
    @FXML
    private TableColumn<Car, String> date_added_column;
    @FXML
    private TableColumn<Car, String> date_sold_column;
    @FXML
    private TableColumn<Car, String> fuel_type_column;
    @FXML
    private TableColumn<Car, Integer> horsepower_column;
    @FXML
    private TableColumn<Car, String> make_column;
    @FXML
    private TableColumn<Car, String> model_column;
    @FXML
    private TableColumn<Car, Integer> owner_id_column;
    @FXML
    private TableColumn<Car, String> photo_url__column;
    @FXML
    private TableColumn<Car, Double> price_column;
    @FXML
    private TableColumn<Car, Boolean> sold_column;
    @FXML
    private TableColumn<Car, Integer> top_speed_column;
    @FXML
    private TableColumn<Car, String> transmission_column;
    @FXML
    private TableColumn<Car, Integer> year_column;
    @FXML
    private Button refresh_btn;

    @FXML
    private PieChart availableCarFuelTypePieChart;
    @FXML
    private AnchorPane availableCarFuelTypePieChartAnchor;
    @FXML
    private PieChart availableCarMakePieChart;
    @FXML
    private AnchorPane availableCarMakePieChartAnchor;

    @FXML
    private Label averageAvailableCarPriceLabel;
    @FXML
    private Label averageAvailableCarYearLabel;
    @FXML
    private AnchorPane averageCarPriceAnchor;
    @FXML
    private AnchorPane averageCarYearAnchor;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        AdminLoginController adminLoginController = AdminLoginController.getInstance();
        this.admin = adminLoginController.admin;

        // Initialize the thread with the user and controller
        AdminThread updateThread = new AdminThread(this);

        // Start the thread
        updateThread.start();

        // Initialize table columns
        car_id_column.setCellValueFactory(new PropertyValueFactory<>("carId"));
        car_type_column.setCellValueFactory(new PropertyValueFactory<>("carType"));
        color_column.setCellValueFactory(new PropertyValueFactory<>("color"));
        date_added_column.setCellValueFactory(new PropertyValueFactory<>("dateAdded"));
        date_sold_column.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
        fuel_type_column.setCellValueFactory(new PropertyValueFactory<>("fuelType"));
        horsepower_column.setCellValueFactory(new PropertyValueFactory<>("horsepower"));
        make_column.setCellValueFactory(new PropertyValueFactory<>("make"));
        model_column.setCellValueFactory(new PropertyValueFactory<>("model"));
        owner_id_column.setCellValueFactory(new PropertyValueFactory<>("ownerId"));
        photo_url__column.setCellValueFactory(new PropertyValueFactory<>("photoURL"));
        price_column.setCellValueFactory(new PropertyValueFactory<>("price"));
        sold_column.setCellValueFactory(new PropertyValueFactory<>("sold"));
        top_speed_column.setCellValueFactory(new PropertyValueFactory<>("topSpeed"));
        transmission_column.setCellValueFactory(new PropertyValueFactory<>("transmission"));
        year_column.setCellValueFactory(new PropertyValueFactory<>("year"));

        // Load data
        loadAvailableCarsTable();
        loadAvailableCarMakePieChart();
        loadAvailableCarFuelTypePieChart();
        loadAverageCarPrice();
        loadAverageCarYear();
    }

    // Method to update information in the UI
    protected void updateInfo() {
        // This method can be used to periodically update information in the UI
    }

    @FXML
    private void switchToAddCars(ActionEvent event) throws IOException {
        App.setRoot("admin-add-cars");
    }

    @FXML
    private void switchToAvailableCars(ActionEvent event) throws IOException {
        App.setRoot("admin-available-cars");
    }

    @FXML
    private void switchToCarsSold(ActionEvent event) throws IOException {
        App.setRoot("admin-cars-sold");
    }

    @FXML
    private void switchToDepositWithdraw(ActionEvent event) throws IOException {
        App.setRoot("admin-deposit-withdraw");
    }

    @FXML
    private void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("admin-view");
    }

    @FXML
    private void switchToSQLView(ActionEvent event) throws IOException {
        App.setRoot("admin-sql");
    }

    @FXML
    private void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }

    @FXML
    private void refreshTable(ActionEvent event) {
        loadAvailableCarsTable();
        loadAvailableCarMakePieChart();
        loadAvailableCarFuelTypePieChart();
        loadAverageCarPrice();
        loadAverageCarYear();
    }

    private void loadAvailableCarsTable() {
        ObservableList<Car> availableCars = FXCollections.observableArrayList(DatabaseHelper.getUnsoldCars());
        cars_available_table.setItems(availableCars);
    }

    private void loadAvailableCarMakePieChart() {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList(DatabaseHelper.getCarCountByMake());
        availableCarMakePieChart.setData(data);
    }

    private void loadAvailableCarFuelTypePieChart() {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList(DatabaseHelper.getCarCountByFuelType());
        availableCarFuelTypePieChart.setData(data);
    }

    private void loadAverageCarPrice() {
        double averagePrice = DatabaseHelper.getAverageCarPrice();
        averageAvailableCarPriceLabel.setText(String.format("$%.2f", averagePrice));
    }

    private void loadAverageCarYear() {
        double averageYear = DatabaseHelper.getAverageCarYear();
        averageAvailableCarYearLabel.setText(String.format("%.0f", averageYear));
    }
    
    
}

    
    
    

