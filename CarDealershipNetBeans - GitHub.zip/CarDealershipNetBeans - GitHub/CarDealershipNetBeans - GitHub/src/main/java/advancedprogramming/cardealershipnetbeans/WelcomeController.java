package advancedprogramming.cardealershipnetbeans;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class WelcomeController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    @FXML
    private Button btn_go_login;

    @FXML
    private Button bttn_go_signup;

    @FXML
    protected void switchToLogin(ActionEvent event) throws Exception {
        App.setRoot("login");

    }

    @FXML
    protected void switchToSignup(ActionEvent event) throws Exception {
        App.setRoot("signup");
    }

}

