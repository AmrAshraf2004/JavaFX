package advancedprogramming.cardealershipnetbeans;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class UserCarsOwnedController implements Initializable {
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        //Get the User who logged in
        
        LoginController loginController = LoginController.getInstance();
        this.user = loginController.user;
        updateInfo();
        loadOwnedCarCards();
        
        // Initialize the thread with the user and controller
        UserThread updateThread = new UserThread(this);

        // Start the thread
        updateThread.start();
    }
    
    // Method to update user information in the UI
    public void updateInfo() {
        name_label.setText(user.getFirstName());
    }
    
    private User user;
    private Car selectedCar;
    
    @FXML
    private Button addMore;
    
    @FXML
    private Button add_balance_btn;

    @FXML
    private Button browse_cars_btn;

    @FXML
    private Button cars_owned_btn;

    @FXML
    private Button home_btn;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label name_label;

    @FXML
    private TextArea CarDetailsTextArea;

    @FXML
    private ScrollPane carBrowseScrollPane;

    @FXML
    private GridPane carCardsGridPane;

    @FXML
    private Button refresh_btn;

    

    

    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900, 600);
        App.setRoot("Welcome");
    }

    @FXML
    void switchToAddBalance(ActionEvent event) throws IOException {
        App.setRoot("user-add-balance");
    }

    @FXML
    void switchToBrowseCars(ActionEvent event) throws IOException {
        App.setRoot("user-browse-cars");
    }

    @FXML
    void switchToCarsOwned(ActionEvent event) throws IOException {
        App.setRoot("user-cars-owned");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("user-view");
    }

    @FXML
    void refreshCars(ActionEvent event) throws Exception {
        loadOwnedCarCards();
    }

    private void loadOwnedCarCards() {
        carCardsGridPane.getChildren().clear(); // Clear any existing cards
        List<Car> cars = DatabaseHelper.getCarsByOwnerId(user.getUserId()); // Load cars owned by the user from the database
        int row = 0;
        int col = 0;

        for (Car car : cars) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("car-card.fxml"));
                AnchorPane carCard = loader.load(); // Change from VBox to AnchorPane
                CarCardController controller = loader.getController(); //Create Card to insert into Grid pane
                controller.setCarDetails(car);

                // Set image
                Image image = new Image(car.getPhotoURL());
                controller.cardCarImage.setImage(image);

                carCardsGridPane.add(carCard, col, row);
                col++;
                if (col == 2) { // Adjust number of columns
                    col = 0;
                    row++;
                }

                // Add event handler for clicking the card
                carCard.setOnMouseClicked(event -> showCarDetails(car));
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to show car details in the text area
    private void showCarDetails(Car car) {
        selectedCar = car;
        CarDetailsTextArea.setText(car.getUserFriendlyDetails()); // only details relevant to user ex: not included dates , id, etc..
    }
}
