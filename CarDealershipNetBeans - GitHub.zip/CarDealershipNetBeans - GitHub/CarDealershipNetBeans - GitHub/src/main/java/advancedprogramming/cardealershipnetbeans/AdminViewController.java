package advancedprogramming.cardealershipnetbeans;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class AdminViewController implements Initializable {
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        AdminLoginController adminLoginController = AdminLoginController.getInstance();
        this.admin = adminLoginController.admin;
        
        // Initialize the thread with the user and controller
        AdminThread updateThread = new AdminThread(this);

        // Start the thread
        updateThread.start();
        
        // Load charts data
        loadProfitsPerDateChart();
        loadCarsSoldPerCarTypeChart();
    }
    
    // Method to update admin information in the UI
    public void updateInfo() {
        home_totalIncome.setText("$"+String.valueOf(DatabaseHelper.getSumOfSoldCarPrices())); 
        home_availableCars.setText(String.valueOf(DatabaseHelper.countNotSoldCars()));
        User.setTotalCustomers();
        home_totalCustomers.setText(String.valueOf(User.getTotalCustomers()));
    }
    
    Admin admin;

    @FXML
    private Button availableCars_btn;

    @FXML
    private Button cars_sold_btn;

    @FXML
    private Button deposit_withdraw_btn;

    @FXML
    private Button go_add_cars_btn;

    @FXML
    private Label home_availableCars;

    @FXML
    private Button home_btn;
    
    @FXML
    private BarChart<String, Number> profitsPerDateChart;
    
    @FXML
    private AnchorPane home_form;

    @FXML
    private BarChart<String, Number> carsSoldPerCarTypeChart;

    @FXML
    private Label home_totalCustomers;

    @FXML
    private Label home_totalIncome;

    @FXML
    private Button logoutBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button sql_btn;

    @FXML
    private Label username;

    @FXML
    void switchToAddCars(ActionEvent event) throws IOException {
        App.setRoot("admin-add-cars");
    }

    @FXML
    void switchToAvailableCars(ActionEvent event) throws IOException {
        App.setRoot("admin-available-cars");
    }

    @FXML
    void switchToCarsSold(ActionEvent event) throws IOException {
        App.setRoot("admin-cars-sold");
    }

    @FXML
    void switchToDepositWithdraw(ActionEvent event) throws IOException {
        App.setRoot("admin-deposit-withdraw");
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        App.setRoot("admin-view");
    }

    @FXML
    void switchToSQLView(ActionEvent event) throws IOException {
        App.setRoot("admin-sql");
    }
    
    @FXML
    void logout(ActionEvent event) throws IOException {
        App.changeSceneSize(900,600);
        App.setRoot("Welcome");
    }
    
    private void loadProfitsPerDateChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        List<XYChart.Data<String, Number>> data = DatabaseHelper.getProfitsPerDate();
        series.getData().addAll(data);
        profitsPerDateChart.getData().clear();
        profitsPerDateChart.getData().add(series);
    }
    
    private void loadCarsSoldPerCarTypeChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        List<XYChart.Data<String, Number>> data = DatabaseHelper.getCarsSoldPerCarType();
        series.getData().addAll(data);
        carsSoldPerCarTypeChart.getData().clear();
        carsSoldPerCarTypeChart.getData().add(series);
    }
}
