package advancedprogramming.cardealershipnetbeans;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;

/**
 * JavaFX App
 */
/*CARZ ALL RIGHTS RESERVED*/
/*By: Amr Ashraf Mahmoud */

public class App extends Application {
    
    
    Image icon = new Image("advancedprogramming/cardealershipnetbeans/images/logo.png"); // Set App Logo

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("Welcome"), 900.0, 600.0);
        stage.setScene(scene);
        stage.setTitle("CARZ");
        stage.getIcons().add(icon);

        stage.show();
    }

    protected static void setRoot(String fxml) throws IOException { // Change FXML Screens
        scene.setRoot(loadFXML(fxml));

    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }
    
    protected static void showAlert(String title, String header, String content) { //Alert Popup Failure
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    protected static void showSuccessAlert(String title, String header, String content) { //Alert Popup Success
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(header);
    alert.setContentText(content);
    alert.showAndWait();
    }

    
    protected static void changeSceneSize(double width, double height) { //Static Method to Change Screen Size
        if (scene != null) {
            scene.getWindow().setWidth(width);
            scene.getWindow().setHeight(height);
        }
    }
    
        // Method to get the controller of a specific scene
    protected static <T> T getController(String fxml) {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fxmlLoader.getController();
    }
    
     protected static boolean showConfirmationDialog(String title, String header, String content) { //Confirmation Popup
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }


    
    public static void main(String[] args) {
        launch();
    }

}